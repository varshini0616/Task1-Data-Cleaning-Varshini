# Task 1: Data Cleaning and Preprocessing

## Objective
Cleaned a raw dataset containing:
- Missing values
- Duplicate rows
- Inconsistent text formats
- Mixed date formats
- Unclean column names

## Steps Performed
1. Identified missing values
2. Removed duplicate records
3. Standardized Gender values
4. Standardized Country names
5. Converted dates to a common format
6. Renamed column headers
7. Corrected data types

## Files
- raw_dataset.csv
- cleaned_dataset.csv
- data_cleaning.py
- summary.txt

GitHub Repository Name Suggestion:
Task1-Data-Cleaning-Varshini
