import pandas as pd

df = pd.read_csv('raw_dataset.csv')

df = df.drop_duplicates()
df['Name'] = df['Name'].fillna('Unknown')
df['Gender'] = df['Gender'].str.strip().str.lower().replace({'f':'female','m':'male'})
df['Country'] = df['Country'].str.lower().replace({'u.s.a.':'usa'}).str.upper()
df['Age'] = pd.to_numeric(df['Age'], errors='coerce')
df['Age'] = df['Age'].fillna(df['Age'].median()).astype(int)
df['Join Date'] = pd.to_datetime(df['Join Date'], errors='coerce', dayfirst=True)
df.columns = [c.lower().replace(' ','_') for c in df.columns]

df.to_csv('cleaned_dataset.csv', index=False)
print(df.head())
